package cn.edu.cqu.greenewsbeta01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import cn.edu.cqu.greenewsbeta01.R;

public class HelpCenterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_center);
    }
}
